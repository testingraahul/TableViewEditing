//
//  ViewController.swift
//  tableTest
//
//  Created by Rahul on 06/07/18.
//  Copyright © 2018 Rahul. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

    @IBOutlet weak var editButton: UIBarButtonItem!
    @IBOutlet weak var tableview: UITableView!
    
    var animalNameArray = ["cat","dog","lion"]

    override func viewDidLoad() {
        super.viewDidLoad()
        tableview.delegate = self
        tableview.dataSource = self
     
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        let defaults = UserDefaults.standard
        let operationArray = defaults.stringArray(forKey: "SavedStringArray") ?? [String]()
        if operationArray.count == 0 {
        }else{
            animalNameArray = operationArray
        }

    }
        
        @IBAction func editButtonAtNavigationBar(_ sender: UIBarButtonItem) {
            self.tableview.isEditing = !self.tableview.isEditing
            sender.title = (self.tableview.isEditing) ?  "Done" : "Edit"
        }
        
        func numberOfSections(in tableView: UITableView) -> Int {
            return 1
        }
        
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return animalNameArray.count
        }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let valueAtCell = tableView.dequeueReusableCell(withIdentifier: "myCustomCell", for: indexPath) as! CustomTableViewCell
            
            valueAtCell.cellLabel?.text = animalNameArray[indexPath.row]
            return valueAtCell
        }
        
        func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            return 100
        }
        
        func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
            if editingStyle == .delete {
                animalNameArray.remove(at: indexPath.row)
                tableView.deleteRows(at: [indexPath], with: .fade)
                print(animalNameArray)

                let defaults = UserDefaults.standard
                defaults.set(animalNameArray, forKey: "SavedStringArray")
                
            } else if editingStyle == .insert {
                // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
            }
        }
        
        func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
            return true
        }
        
        //Rearranging the table view cells
        
        func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
            let itemMove = animalNameArray[sourceIndexPath.row]
            animalNameArray.remove(at: sourceIndexPath.row)
            animalNameArray.insert(itemMove, at: destinationIndexPath.row)
            
            print(animalNameArray)
        }
    

    }
    
    
    
    
    


